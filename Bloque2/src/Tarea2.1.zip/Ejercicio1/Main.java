package Ejercicio1;

public class Main {
    public static void main(String[] args) {
        Hilo hilo1 = new Hilo(1);
        Hilo hilo2 = new Hilo(2);
        Hilo hilo3 = new Hilo(3);
        Hilo hilo4 = new Hilo(4);
        Hilo hilo5 = new Hilo(5);
    }
}
